package com.sh.trippies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
