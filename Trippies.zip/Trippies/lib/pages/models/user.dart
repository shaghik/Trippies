class User {
  final String uid;

  User({
    required this.uid
  });
}