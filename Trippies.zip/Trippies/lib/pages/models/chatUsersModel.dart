import 'package:flutter/cupertino.dart';

class ChatUsers{
  String text;
  String image;
  String secondaryText;
  String time;
  ChatUsers({required this.text,required this.secondaryText,required this.image,required this.time});
}