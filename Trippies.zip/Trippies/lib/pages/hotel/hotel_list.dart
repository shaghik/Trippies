import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:Trippies/constant/constant.dart';
import 'package:Trippies/widget/column_builder.dart';
import 'package:Trippies/pages/hotel/hotel_list.dart';

class HotelList extends StatefulWidget {
  @override
  _HotelListState createState() => _HotelListState();
}

class _HotelListState extends State<HotelList> {
  @override
  Widget(BuildContext context) {
    SizedBox(height: 20.0);
    Padding(
        padding: EdgeInsets.only(right: 20.0, left: 20.0),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.grey[200]!.withOpacity(0.3),
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
          ),
          child: TextField(
            style: inputLoginTextStyle,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(left: 20.0),
              hintText: 'Email',
              hintStyle: inputLoginTextStyle,
              border: InputBorder.none,
            ),

          ),

        ));
  }

  @override
  noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}
