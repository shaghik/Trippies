import 'package:flutter/material.dart';
import 'package:Trippies/pages/BillSplitter/colorss.dart';
import 'package:Trippies/pages/BillSplitter/hexcolor.dart';
import 'package:Trippies/pages/BillSplitter/multi.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';


class Ova extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
      ),
      home: Calci(),
    );
  }
}





class Calci extends StatefulWidget
{
  @override
  _CalcuState createState() => _CalcuState();
}
class _CalcuState extends State<Calci> {
  int tipPercent = 0;
  int personCount = 2;
  double billAmount = 0.0;
  Color purple = HexColor("#6908D6");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Trip Expenses",style: TextStyle(
          fontStyle: FontStyle.italic,
          fontSize: 34.0,
          color: Colors.yellow,
        ),),
        centerTitle: true,
        backgroundColor: primaryIndigoP,
        //backgroundColor:Colors.cyan ,
      ),
      backgroundColor:primaryV,
      body: Container( //parent main box
        margin: EdgeInsets.only(top: MediaQuery//margin mnz it ll come down//dynamic height ch
            .of(context)
            .size
            .height * 0.1),
        alignment: Alignment.center,
        color: primaryV,
        child: ListView( //multi values
          scrollDirection: Axis.vertical,
          padding: EdgeInsets.all(20.5),//to cone center
          children: <Widget>[
            Container(//box
              height: 200,
              width: 200,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20.5),

              ),
              child: Center(
                child: Column( //when we enter a text inside block
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[  // text
                    Text(" Total per person",style: TextStyle(fontStyle: FontStyle.italic,
                      fontSize: 25,
                      color: Colors.black,

                    ),),
                    Padding(// second text inside gap
                      padding: const EdgeInsets.all(20.0),
                      child:  Text("\$ ${calculateTotalPer(billAmount, personCount,tipPercent )}",style: TextStyle(fontSize:40.0 ,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),),
                    ),


                  ],

                ),
              ),


            ),

            Container(
              margin: EdgeInsets.only(top: 20.2),
              padding: EdgeInsets.all(20.2),
              decoration: BoxDecoration(
                color: Colors.white70,
                border: Border.all(
                  color: Colors.black12,
                  style: BorderStyle.solid,

                ),
                borderRadius: BorderRadius.circular(22.5),
              ),


              child: Column(
                children: <Widget>[
                  TextField(///many methods
                    keyboardType: TextInputType.numberWithOptions(
                        decimal: true),
                    style: TextStyle(color: Colors.redAccent,fontStyle: FontStyle.italic,fontWeight: FontWeight.w600,fontSize: 20.0),
                    decoration: InputDecoration(//text inside decoration
                      prefixText: "total amt: ",prefixStyle: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w700,
                    ),
                      prefixIcon: Icon(Icons.attach_money,
                        color: primaryJ,
                      ),


                    ),
                    onChanged: (String value) {
                      try {
                        billAmount = double.parse(value);//value with get after paring
                      }
                      catch (exception) {
                        billAmount = 0.0;
                      }
                    },
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("Number of people", style: TextStyle(
                        fontSize: 15.0,
                        fontStyle: FontStyle.italic,
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                      ),),
                      Row(
                        children: <Widget>[
                          InkWell(//to working of bocxxx
                            onTap: () {
                              setState(() {
                                if (personCount > 1) {
                                  personCount--;
                                }
                                else {
                                  //niog
                                }
                              });
                            },
                            child: Container(
                              width: 40.0,
                              height: 30.0,
                              margin: EdgeInsets.all(10.5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.5),
                                color: Colors.purple.withOpacity(0.2),

                              ),
                              child: Center(
                                child: Text("-", style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 20.0,

                                ),),
                              ),


                            ),

                          ),
                          Text("$personCount", style: TextStyle(
                            color: Colors.black,
                            fontStyle: FontStyle.italic,fontWeight: FontWeight.bold,

                          ),),
                          InkWell(
                            onTap: () {
                              setState(() {
                                personCount++;
                              });
                            },
                            child: Container(
                              width: 40.0,
                              height: 30.0,
                              margin: EdgeInsets.all(10.5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.5),
                                color: purple.withOpacity(0.2),
                              ),
                              child: Center(
                                child: Text("+", style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 17.0,
                                ),),
                              ),
                            ),



                          ),


                        ],
                      ),

                    ],
                  ),
                ],

              ),
            ),
           /* Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child:  Text("tip", style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.black,
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                  ),),
                ),
                Text("\$ ${calculateTotal(billAmount, personCount, tipPercent)}",style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20.0
                ),),
              ],

            ),


            Column(
              children: <Widget>[
                Text("$tipPercent%", style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.brown,
                  fontWeight: FontWeight.w900,
                ),),
                Slider(
                  min: 0,
                  max: 100,
                  activeColor: Colors.blueGrey,
                  inactiveColor: secondaryD,
                  divisions: 100,
                  value: tipPercent.toDouble(),
                  onChanged: (double newValue) {
                    setState(() {
                      tipPercent = newValue.round();//it will run fully
                    });
                  },


                )




              ],


            ),
          ],

            */

        ]),
      ),
    );


  }



  calculateTotalPer(double billAmount,int splitBy,int tipPercent) {
    var totalPeer = (calculateTotal(billAmount, splitBy, tipPercent) + billAmount)/splitBy;
    return totalPeer.toStringAsFixed(2);
  }

  calculateTotal(double billAmount, int splitBy, int tipPercent) {
    double totTip = 0.0;
    if (billAmount < 0 || billAmount
        .toString()
        .isEmpty || billAmount == null) {
//no
    }
    else {
      totTip = (tipPercent * billAmount) / 100;
    }
    return totTip;
  }

}



