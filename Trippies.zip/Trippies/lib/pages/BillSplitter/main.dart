import 'package:flutter/material.dart';
import 'package:Trippies/pages/BillSplitter/page.dart';

void main() =>runApp(new MaterialApp(home:PageViewDemo ()



)
);