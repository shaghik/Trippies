import 'package:Trippies/pages/Reminder.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:Trippies/constant/constant.dart';



void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: Colors.black,
      ),
      home: Transportation(),
    );
  }
}

class Transportation extends StatefulWidget {
  @override
  _Transportation createState() => _Transportation();
}

class _Transportation extends State<Transportation> {
  var selectedCurrency, selectedType;
  final GlobalKey<FormState> _formKeyValue = new GlobalKey<FormState>();
  List<String> _accountType = <String>[
    'Car','Airplane','Train','Bus','Other'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Container(
            child: Text("\t\t\t\t\t\t\t\t\t\tTransportation",
                style: TextStyle(
                  color: Colors.white,
                )),
          ),
          actions: <Widget>[
          ],
        ),
        body: Form(
          key: _formKeyValue,
          autovalidate: true,
          child: new ListView(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            children: <Widget>[
              SizedBox(height: 80.0),
              new TextFormField(
                  decoration: const InputDecoration(
                    icon: const Icon(
                      FontAwesomeIcons.userCircle,
                      color: Colors.black,
                    ),

                    hintText: 'Person who will be driving',
                    labelText: 'Name',
                  ),
                  keyboardType: TextInputType.name
              ),

              Text('\n'),
              new TextFormField(
                decoration: const InputDecoration(
                  icon: const Icon(
                    FontAwesomeIcons.gasPump,
                    color: Colors.black,
                  ),
                  hintText: 'Cost of gas',
                  labelText: 'GAS',
                ),
                inputFormatters: [CurrencyTextInputFormatter()],
                keyboardType: TextInputType.number,
              ),
              Text('\n\n'),

          Container(
            margin: EdgeInsets.all(fixPadding),
            padding: EdgeInsets.all(fixPadding),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  blurRadius: 10,
                  spreadRadius: 10,
                 // color: Colors.grey![500],
                ),
              ],
            ),
            child: Column(
                children: <Widget>[

                InkWell(
                onTap: () {
          Navigator.push(
          context,
          PageTransition(
          duration: Duration(milliseconds: 400),
          type: PageTransitionType.rightToLeft,
          child: AppState()));
              //child: Transportation()));
          },
            child: getTile(
                Icon(Icons.access_alarms_outlined,
                    color: Colors.grey.withOpacity(1.0)),
                'Break Reminder'),
          ),

                    ])

                ),
                ]))
    );
  }

                getTile(Icon icon, String title) {
    return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: <Widget>[
    Row(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: <Widget>[
    Container(
    height: 100.0,
    width: 100.0,
    alignment: Alignment.center,
    child: icon,
    ),
    widthSpace,
    Text(
    title,
    style: blackSmallTextStyle,
    ),
    ],
    ),
    Icon(
    Icons.arrow_forward_ios,
    size: 50.0,
    color: Colors.grey.withOpacity(0.6),
    ),
    ],
    );


  }
}