import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:Trippies/constant/constant.dart';
import 'package:Trippies/pages/splashScreen.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  get textEditingController => null;
  @override

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Container(
            child: Text("\t\tAccommodation Options",
                style: TextStyle(
                  color: Colors.white,

                )),
          ),
          //actions: <Widget>[
         // ],
        ),
  //Widget build(BuildContext context) {
    //final TextEditingController _controller = TextEditingController();
   // return Scaffold(
      backgroundColor: Colors.black,
      body: ListView(
        children: [
          //heightSpace,
         // heightSpace,
          Container(
           // padding: EdgeInsets.all(fixPadding * 0),
            child: Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,

                ),

                  Container(
                    width: 60.0,
                    height: 20.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
              ],
            ),
          ),

          // Search Start
          Container(
            height: 100,
            padding: EdgeInsets.all(fixPadding * 0.5),
            margin: EdgeInsets.all(fixPadding * 1.0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: CupertinoColors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(width: 0, color: greyColor.withOpacity(0)),

            ),


              child: TextFormField(
                keyboardType: TextInputType.name,
                autofocus: false,
                controller: textEditingController,

                decoration: InputDecoration(
                  labelText: ' Accommodation links',
                  hintText: 'Name or the link to the website',
                  prefixIcon: IconButton(
                    onPressed: () async {
                      if(textEditingController.text.toString() == null || textEditingController.text.toString() == ""){
                        print("null data");
                      }else{
                        print(textEditingController.text.toString());
                        if (await canLaunch("https://" + textEditingController.text.toString())) {
                          await launch("https://" + textEditingController.text.toString());
                        } else {
                          throw 'Could not launch ${textEditingController.text.toString()}';
                        }
                      }
                    },
                    icon: Icon(Icons.open_in_browser),
                  ),
                ),
                maxLength: 1000,
              ),

          ),

          Container(
              height: 100,
              padding: EdgeInsets.all(fixPadding * 0.5),
              margin: EdgeInsets.all(fixPadding * 1.0),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: CupertinoColors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(width: 0, color: greyColor.withOpacity(0)),
    ),

          child: TextFormField(
              keyboardType: TextInputType.name,
              autofocus: false,
              controller: textEditingController,

          decoration: InputDecoration(
            labelText: ' Accommodation links',
            hintText: 'Name or the link to the website',
            prefixIcon: IconButton(
            onPressed: () async {
              if(textEditingController.text.toString() == null || textEditingController.text.toString() == ""){
                print("null data");
              }else{
                print(textEditingController.text.toString());
                if (await canLaunch("https://" + textEditingController.text.toString())) {
                  await launch("https://" + textEditingController.text.toString());
                } else {
                  throw 'Could not launch ${textEditingController.text.toString()}';
                }
              }
            },
            icon: Icon(Icons.open_in_browser),
          ),
        ),
        maxLength: 1000,
      ),
          ),

          Container(
            height: 100,
            padding: EdgeInsets.all(fixPadding * 0.5),
            margin: EdgeInsets.all(fixPadding * 1.0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: CupertinoColors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(width: 0, color: greyColor.withOpacity(0)),
            ),

            child: TextFormField(
              keyboardType: TextInputType.name,
              autofocus: false,
              controller: textEditingController,

              decoration: InputDecoration(
                labelText: ' Accommodation links',
                hintText: 'Name or the link to the website',
                prefixIcon: IconButton(
                  onPressed: () async {
                    if(textEditingController.text.toString() == null || textEditingController.text.toString() == ""){
                      print("null data");
                    }else{
                      print(textEditingController.text.toString());
                      if (await canLaunch("https://" + textEditingController.text.toString())) {
                        await launch("https://" + textEditingController.text.toString());
                      } else {
                        throw 'Could not launch ${textEditingController.text.toString()}';
                      }
                    }
                  },
                  icon: Icon(Icons.open_in_browser),
                ),
              ),
              maxLength: 1000,
            ),
          ),
        Container(
          height: 100,
          padding: EdgeInsets.all(fixPadding * 0.5),
          margin: EdgeInsets.all(fixPadding * 1.0),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: CupertinoColors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(width: 0, color: greyColor.withOpacity(0)),

          ),
          child: TextFormField(
            keyboardType: TextInputType.name,
            autofocus: false,
            controller: textEditingController,

            decoration: InputDecoration(
              labelText: ' Accommodation links',
              hintText: 'Name or the link to the website',
              prefixIcon: IconButton(
                onPressed: () async {
                  if(textEditingController.text.toString() == null || textEditingController.text.toString() == ""){
                    print("null data");
                  }else{
                    print(textEditingController.text.toString());
                    if (await canLaunch("https://" + textEditingController.text.toString())) {
                      await launch("https://" + textEditingController.text.toString());
                    } else {
                      throw 'Could not launch ${textEditingController.text.toString()}';
                    }
                  }
                },
                icon: Icon(Icons.open_in_browser),
              ),
            ),
            maxLength: 1000,
          ),

        )],
      ),
    );
  }



  launch(String s) {}

  canLaunch(String s) {}
}


