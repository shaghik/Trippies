import 'dart:io';
import 'package:Trippies/pages/BillSplitter/page.dart';
import 'package:Trippies/pages/Chat/chat_page.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:Trippies/pages/Transportation/Transportation.dart';
import 'package:Trippies/constant/constant.dart';
import 'package:Trippies/pages/BillSplitter/main.dart';
import 'package:Trippies/pages/Chat/search_page.dart';
import 'package:Trippies/pages/home/home.dart';
import 'package:Trippies/pages/profile/profile.dart';
import 'package:Trippies/pages/Reminder.dart';

class BottomBar extends StatefulWidget {
  @override
  _BottomBarState createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  int currentIndex = 0;
  late DateTime currentBackPressTime;

  changeIndex(index) {
    setState(() {
      currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 80.0,
        child: BottomAppBar(
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              getBottomBarItemTile(0, Icons.chat),
              getBottomBarItemTile(1, Icons.hotel),
              getBottomBarItemTile(2, Icons.flight_takeoff),
              getBottomBarItemTile(3, Icons.attach_money),
              getBottomBarItemTile(4, Icons.person),
            ],
          ),
        ),
      ),
      body: WillPopScope(
        child: (currentIndex == 0)
           ? SearchPage()
            : (currentIndex == 1)
                ? Home()
                : (currentIndex == 2)
                   ? Transportation()
                    : (currentIndex == 3) ? PageViewDemo() : Profile(),
        onWillPop: () async {
          bool backStatus = onWillPop();
          if (backStatus) {
            exit(0);
          }
          return false;
        },
      ),

    );
  }

  getBottomBarItemTile(int index, icon) {
    return InkWell(
      borderRadius: BorderRadius.circular(30.0),
      focusColor: primaryColor,
      onTap: () {
        changeIndex(index);
      },
      child: Container(
        height: 60.0,
        width: 60.0,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          color:
              (currentIndex == index) ? Colors.grey[100] : Colors.transparent,
        ),
        child: Icon(icon,
            size: 30.0,
            color: (currentIndex == index) ? primaryColor : greyColor),
      ),
    );
  }

  onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(
        msg: 'Press Back Once Again to Exit.',
        backgroundColor: Colors.black,
        textColor: whiteColor,
      );
      return false;
    } else {
      return true;
    }
  }
}
