import 'package:flutter/material.dart';
import 'package:Trippies/pages/helper/helper_functions.dart';
import 'package:Trippies/pages/Chat/home_page.dart';

void main() => runApp(MyChatApp());

class MyChatApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyChatApp> {

  bool _isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    _getUserLoggedInStatus();
  }

  _getUserLoggedInStatus() async {
    await HelperFunctions.getUserLoggedInSharedPreference().then((value) {
      if(value != null) {
        setState(() {
          _isLoggedIn = value;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Group Chats',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
     // home: _isLoggedIn != null ? _isLoggedIn ? HomePage() : AuthenticatePage() : Center(child: CircularProgressIndicator()),
      home:  HomePage()
      //home: HomePage(),
    );
  }
}