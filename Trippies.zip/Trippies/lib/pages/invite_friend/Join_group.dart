import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:Trippies/constant/constant.dart';
import 'dart:math';

class JoinGroup extends StatefulWidget {
  @override
  _JoinGroup createState() => _JoinGroup();
}



class _JoinGroup extends State<JoinGroup> {

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: whiteColor,
        appBar: AppBar(
          backgroundColor: whiteColor,
          elevation: 1.0,
          titleSpacing: 0.0,
          title: Text(
            'Join an existing group',
            style: appBarTextStyle,
          ),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: blackColor,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: ListView(
            children: [
              heightSpace,
              Container(
                color: Colors.grey[200],
                padding: EdgeInsets.all(fixPadding * 2.0),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Enter the code: ',
                        style: blackSmallTextStyle,
                      ),
                      heightSpace,
                      DottedBorder(
                        borderType: BorderType.RRect,
                        radius: Radius.circular(10),
                        strokeWidth: 1.2,
                        color: greyColor.withOpacity(0.6),
                        child: ClipRRect(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          child: Container(
                            width: 200.0,
                            padding: EdgeInsets.all(fixPadding),
                            decoration: BoxDecoration(color: whiteColor),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,


                              children: [

                                InkWell(
                                  onTap: () {},

                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ]
                ),
              )]
        ));
  }
}
